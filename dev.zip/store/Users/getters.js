export default{
  User(state){return state.user},
  valets(state){return state.valets},
  upload(store){return store.upload},
  singlUpload(store){return store.singlUpload},
  errMsg(state){return state.errMsg}
}