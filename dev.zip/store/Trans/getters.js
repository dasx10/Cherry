export default{
    transactions(store){return store.transactions},
    upload(store){return store.upload}
}