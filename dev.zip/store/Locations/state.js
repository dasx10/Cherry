export default()=>({
  locations:[],
  location:{
    index:null,
    id_airport:null,
    airport_name:'',
    address:'',
    longitude:0,
    latitude:0,
    one_night_cost:0
  },
  upload:false,
  singlUpload:false,
})