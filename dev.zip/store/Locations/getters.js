export default{
  locations(state){return state.locations},
  location(state){return state.location},
  upload(store){return store.upload},
  singlUpload(store){return store.singlUpload},
}